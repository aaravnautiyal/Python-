print("**********WELCOME TO THE QUIZ**********")

QUESTIONS = [
    ["Which team has won the T20 world cup 2024 ?", "Australia", "England", "India", "USA", 3],
    ["Which is the national flower of India ?", "Rose", "Lotus", "Sunflower", "Lily", 2],
    ["When was the bulb invented?", "1934", "1764", "1691", "1878", 4],
    ["Which country has won the World Cup many times ?", "Australia", "New Zealand", "India", "Pakistan", 1],
]

PRICE = [1000, 5000, 12000, 20000]
MONEY = 0
for i in range(0, len(QUESTIONS)):
    X = QUESTIONS[i]

    print(f"\nQUESTION FOR RS.{PRICE[i]}")
    print(X[0])
    print(f"1.{X[1]}          2.{X[2]}")
    print(f"3.{X[3]}          4.{X[4]}")

    REPLY = int(input("Select the number from 1-4\n"))

    if(REPLY == X[-1]):
        print(f"CONGRATULATIONS, YOU HAVE WON: {PRICE[i]}")
        if(i==0):
            MONEY = 1000
        elif(i==1):
            MONEY = 5000
        elif(i==2):
            MONEY = 12000
        elif(i==3):
            MONEY = 20000
    else:
        print("OOPS!!, YOU LOSE")
        break
print(f"YOU EARNED TOTAL WINNING: {MONEY}")

